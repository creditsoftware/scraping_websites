# web_scraper_brian_mcmahon
An undetectable web scraper written for Brian McMahon
